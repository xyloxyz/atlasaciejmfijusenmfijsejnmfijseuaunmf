async loadBanList() {
  if (!this.currentServer) return;

  const banList = document.getElementById('banList');
  if (!banList) return;

  try {
    banList.innerHTML = '<div class="loading-state"><i class="fas fa-spinner fa-spin"></i> Loading bans...</div>';

    const response = await axios.get(`/discord-management/server/${this.currentServer}/bans`);
    
    if (response.data.success) {
      this.renderBanList(response.data.bans);
      this.updateBanStats(response.data.total);
    } else {
      banList.innerHTML = '<div class="error-state">Error loading ban list</div>';
    }
  } catch (error) {
    console.error('Error loading ban list:', error);
    banList.innerHTML = '<div class="error-state">Error loading ban list</div>';
  }
}

renderBanList(bans) {
  const banList = document.getElementById('banList');
  if (!banList) return;

  if (bans.length === 0) {
    banList.innerHTML = '<div class="empty-state">No banned users found</div>';
    return;
  }

  const html = bans.map(ban => {
    const user = ban.user;
    const reason = ban.reason || 'No reason provided';
    const additionalInfo = ban.additional_info || {};
    const evidence = additionalInfo.evidence;
    const notes = additionalInfo.notes;
    const expireAt = additionalInfo.expire_at;
    
    const avatar = user.avatar 
      ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=128`
      : 'path/to/default/avatar.png';

    return `
      <div class="ban-card" data-user-id="${user.id}">
        <div class="ban-header">
          <img src="${avatar}" alt="${user.username}" class="ban-avatar">
          <div class="ban-user-info">
            <h3>${this.escapeHtml(user.username)}</h3>
            <p class="user-id">ID: ${user.id}</p>
          </div>
          <div class="ban-actions">
            <button class="btn btn-sm btn-info" onclick="discordManager.viewBanDetails('${user.id}')">
              <i class="fas fa-info-circle"></i>
            </button>
            <button class="btn btn-sm btn-warning" onclick="discordManager.editBan('${user.id}')">
              <i class="fas fa-edit"></i>
            </button>
            <button class="btn btn-sm btn-danger" onclick="discordManager.unbanUser('${user.id}')">
              <i class="fas fa-user-check"></i>
            </button>
          </div>
        </div>
        <div class="ban-details">
          <div class="ban-reason">
            <strong>Reason:</strong> ${this.escapeHtml(reason)}
          </div>
          ${evidence ? `
            <div class="ban-evidence">
              <strong>Evidence:</strong>
              <div class="evidence-content">${this.escapeHtml(evidence)}</div>
            </div>
          ` : ''}
          ${notes ? `
            <div class="ban-notes">
              <strong>Notes:</strong>
              <div class="notes-content">${this.escapeHtml(notes)}</div>
            </div>
          ` : ''}
          ${expireAt ? `
            <div class="ban-expiry">
              <strong>Expires:</strong> ${new Date(expireAt).toLocaleString()}
            </div>
          ` : ''}
          <div class="ban-timestamp">
            <small>Banned: ${new Date(ban.created_at).toLocaleString()}</small>
          </div>
        </div>
      </div>
    `;
  }).join('');

  banList.innerHTML = html;
}

updateBanStats(total) {
  const statsElement = document.getElementById('banStats');
  if (statsElement) {
    statsElement.innerHTML = `
      <div class="stat-item">
        <div class="stat-value">${total}</div>
        <div class="stat-label">Total Bans</div>
      </div>
    `;
  }
}

async viewBanDetails(userId) {
  try {
    const response = await axios.get(`/discord-management/server/${this.currentServer}/bans/${userId}`);
    
    if (response.data.success) {
      const ban = response.data.ban;
      const modalContent = this.createBanDetailsModal(ban);
      
      const modal = new bootstrap.Modal(document.getElementById('banDetailsModal'));
      document.getElementById('banDetailsModalContent').innerHTML = modalContent;
      modal.show();
    } else {
      this.showNotification('Error fetching ban details', 'error');
    }
  } catch (error) {
    console.error('Error viewing ban details:', error);
    this.showNotification('Error fetching ban details', 'error');
  }
}

createBanDetailsModal(ban) {
  const user = ban.user;
  const additionalInfo = ban.additional_info || {};
  
  return `
    <div class="modal-header">
      <h5 class="modal-title">Ban Details - ${this.escapeHtml(user.username)}</h5>
      <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
    </div>
    <div class="modal-body">
      <div class="ban-details-content">
        <div class="user-section">
          <img src="https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=256" 
               alt="${user.username}" 
               class="user-avatar-large">
          <div class="user-info">
            <h3>${this.escapeHtml(user.username)}</h3>
            <p>ID: ${user.id}</p>
          </div>
        </div>
        
        <div class="details-section">
          <h4>Ban Information</h4>
          <p><strong>Reason:</strong> ${this.escapeHtml(ban.reason || 'No reason provided')}</p>
          <p><strong>Banned At:</strong> ${new Date(additionalInfo.created_at || Date.now()).toLocaleString()}</p>
          ${additionalInfo.expire_at ? `
            <p><strong>Expires At:</strong> ${new Date(additionalInfo.expire_at).toLocaleString()}</p>
          ` : ''}
        </div>
        
        ${additionalInfo.evidence ? `
          <div class="evidence-section">
            <h4>Evidence</h4>
            <div class="evidence-content">
              ${this.escapeHtml(additionalInfo.evidence)}
            </div>
          </div>
        ` : ''}
        
        ${additionalInfo.notes ? `
          <div class="notes-section">
            <h4>Notes</h4>
            <div class="notes-content">
              ${this.escapeHtml(additionalInfo.notes)}
            </div>
          </div>
        ` : ''}
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      <button type="button" class="btn btn-warning" onclick="discordManager.editBan('${user.id}')">
        <i class="fas fa-edit"></i> Edit Ban
      </button>
      <button type="button" class="btn btn-danger" onclick="discordManager.unbanUser('${user.id}')">
        <i class="fas fa-user-check"></i> Unban User
      </button>
    </div>
  `;
}

async editBan(userId) {
  try {
    const response = await axios.get(`/discord-management/server/${this.currentServer}/bans/${userId}`);
    
    if (response.data.success) {
      const ban = response.data.ban;
      const modalContent = this.createBanEditModal(ban);
      
      const modal = new bootstrap.Modal(document.getElementById('banEditModal'));
      document.getElementById('banEditModalContent').innerHTML = modalContent;
      modal.show();
      
      document.getElementById('banEditForm').addEventListener('submit', (e) => {
        e.preventDefault();
        this.updateBanInfo(userId, new FormData(e.target));
      });
    } else {
      this.showNotification('Error fetching ban information', 'error');
    }
  } catch (error) {
    console.error('Error editing ban:', error);
    this.showNotification('Error fetching ban information', 'error');
  }
}

createBanEditModal(ban) {
  const user = ban.user;
  const additionalInfo = ban.additional_info || {};
  
  return `
    <div class="modal-header">
      <h5 class="modal-title">Edit Ban - ${this.escapeHtml(user.username)}</h5>
      <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
    </div>
    <div class="modal-body">
      <form id="banEditForm">
        <div class="mb-3">
          <label class="form-label">Evidence</label>
          <textarea class="form-control" name="evidence" rows="3">${this.escapeHtml(additionalInfo.evidence || '')}</textarea>
          <small class="text-muted">Add any evidence or proof related to this ban</small>
        </div>
        
        <div class="mb-3">
          <label class="form-label">Notes</label>
          <textarea class="form-control" name="notes" rows="3">${this.escapeHtml(additionalInfo.notes || '')}</textarea>
          <small class="text-muted">Add any additional notes or comments</small>
        </div>
        
        <div class="mb-3">
          <label class="form-label">Expire At</label>
          <input type="datetime-local" class="form-control" name="expireAt" 
                 value="${additionalInfo.expire_at ? new Date(additionalInfo.expire_at).toISOString().slice(0, 16) : ''}">
          <small class="text-muted">Set when this ban should automatically expire (optional)</small>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
      <button type="submit" form="banEditForm" class="btn btn-primary">
        <i class="fas fa-save"></i> Save Changes
      </button>
    </div>
  `;
}

async updateBanInfo(userId, formData) {
  try {
    const response = await axios.patch(`/discord-management/server/${this.currentServer}/bans/${userId}`, {
      evidence: formData.get('evidence'),
      notes: formData.get('notes'),
      expireAt: formData.get('expireAt') || null
    });
    
    if (response.data.success) {
      this.showNotification('Ban information updated successfully', 'success');
      bootstrap.Modal.getInstance(document.getElementById('banEditModal')).hide();
      this.loadBanList();
    } else {
      this.showNotification('Failed to update ban information', 'error');
    }
  } catch (error) {
    console.error('Error updating ban information:', error);
    this.showNotification('Error updating ban information', 'error');
  }
}

async unbanUser(userId) {
  if (!confirm('Are you sure you want to unban this user?')) return;
  
  try {
    const response = await axios.delete(`/discord-management/server/${this.currentServer}/ban/${userId}`);
    
    if (response.data.success) {
      this.showNotification('User unbanned successfully', 'success');
      this.loadBanList();
      
      const detailsModal = bootstrap.Modal.getInstance(document.getElementById('banDetailsModal'));
      const editModal = bootstrap.Modal.getInstance(document.getElementById('banEditModal'));
      if (detailsModal) detailsModal.hide();
      if (editModal) editModal.hide();
    } else {
      this.showNotification('Failed to unban user: ' + response.data.error, 'error');
    }
  } catch (error) {
    console.error('Error unbanning user:', error);
    this.showNotification('Error unbanning user', 'error');
  }
}

setupEventListeners() {
  
  const refreshBansBtn = document.getElementById('refreshBansBtn');
  if (refreshBansBtn) {
    refreshBansBtn.addEventListener('click', () => this.loadBanList());
  }
  
  const banSearch = document.getElementById('banSearch');
  if (banSearch) {
    banSearch.addEventListener('input', (e) => {
      const searchTerm = e.target.value.toLowerCase();
      const banCards = document.querySelectorAll('.ban-card');
      
      banCards.forEach(card => {
        const username = card.querySelector('.ban-user-info h3').textContent.toLowerCase();
        const userId = card.querySelector('.user-id').textContent.toLowerCase();
        const reason = card.querySelector('.ban-reason').textContent.toLowerCase();
        
        if (username.includes(searchTerm) || userId.includes(searchTerm) || reason.includes(searchTerm)) {
          card.style.display = 'block';
        } else {
          card.style.display = 'none';
        }
      });
    });
  }
}

async switchTab(tabName) {
  
  if (tabName === 'bans') {
    await this.loadBanList();
  }
}

export default DiscordManager; 