class DiscordManager {
    constructor() {
        this.currentServer = null;
        this.currentMembers = [];
        this.currentPage = 1;
        
        setTimeout(() => {
            this.init();
        }, 100);
    }

    init() {
        try {
            this.setupEventListeners();
            this.setupTabSwitching();
            this.loadInitialData();
        } catch (error) {
            console.error('Error in DiscordManager init:', error);
        }
    }

    setupEventListeners() {
        
        const serverTabs = document.querySelectorAll('.server-tab');
        serverTabs.forEach((tab, index) => {
            tab.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                const serverId = e.target.closest('.server-tab').dataset.server;
                this.switchServer(serverId);
            });
        });

        const managementTabs = document.querySelectorAll('.management-tab');
        managementTabs.forEach((tab, index) => {
            tab.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                const tabName = e.target.dataset.tab;
                this.switchTab(tabName);
            });
        });

        this.setupForms();

        const memberSearch = document.getElementById('memberSearch');
        if (memberSearch) {
            memberSearch.addEventListener('input', (e) => {
                this.searchMembers(e.target.value);
            });
        }

        this.setupEmbedPreview();
        
    }

    setupTabSwitching() {
        const tabs = document.querySelectorAll('.management-tab');
        const contents = document.querySelectorAll('.tab-content');

        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                tabs.forEach(t => t.classList.remove('active'));
                contents.forEach(c => c.classList.remove('active'));
                
                tab.classList.add('active');
                document.getElementById(tab.dataset.tab).classList.add('active');
            });
        });
    }

    setupForms() {
        document.getElementById('banForm')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            await this.banUser({
                userId: formData.get('userId'),
                reason: formData.get('reason'),
                deleteMessageDays: formData.get('deleteMessageDays')
            });
        });

        document.getElementById('kickForm')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            await this.kickUser({
                userId: formData.get('userId'),
                reason: formData.get('reason')
            });
        });

        document.getElementById('timeoutForm')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            await this.timeoutUser({
                userId: formData.get('userId'),
                duration: formData.get('duration'),
                reason: formData.get('reason')
            });
        });

        document.getElementById('unbanForm')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            await this.unbanUser({
                userId: formData.get('userId'),
                reason: formData.get('reason')
            });
        });

        document.getElementById('messageForm')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            await this.sendMessage({
                channelId: formData.get('channelId'),
                content: formData.get('content')
            });
        });

        document.getElementById('embedForm')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            await this.sendEmbed({
                channelId: formData.get('channelId'),
                title: formData.get('title'),
                description: formData.get('description'),
                color: formData.get('color'),
                footer: formData.get('footer')
            });
        });
    }

    setupEmbedPreview() {
        const form = document.getElementById('embedForm');
        if (!form) return;

        const inputs = form.querySelectorAll('input, textarea');
        inputs.forEach(input => {
            input.addEventListener('input', () => {
                this.updateEmbedPreview();
            });
        });
    }

    updateEmbedPreview() {
        const title = document.querySelector('[name="title"]')?.value || '';
        const description = document.querySelector('[name="description"]')?.value || '';
        const color = document.querySelector('[name="color"]')?.value || '#5865f2';
        const footer = document.querySelector('[name="footer"]')?.value || '';

        const preview = document.getElementById('embedPreview');
        if (!preview) return;

        let html = '<div style="border-left: 4px solid ' + color + '; padding-left: 1rem;">';
        
        if (title) {
            html += '<div style="color: var(--text-primary); font-weight: 600; margin-bottom: 0.5rem;">' + this.escapeHtml(title) + '</div>';
        }
        
        if (description) {
            html += '<div style="color: var(--text-secondary); margin-bottom: 0.5rem;">' + this.escapeHtml(description).replace(/\n/g, '<br>') + '</div>';
        }
        
        if (footer) {
            html += '<div style="color: var(--text-secondary); font-size: 0.8rem; margin-top: 0.5rem;">' + this.escapeHtml(footer) + '</div>';
        }

        if (!title && !description && !footer) {
            html += '<div style="color: var(--text-secondary);">Fill out the form above to see a preview</div>';
        }
        
        html += '</div>';
        preview.innerHTML = html;
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    async loadInitialData() {
        const activeTab = document.querySelector('.server-tab.active');
        if (activeTab) {
            this.currentServer = activeTab.dataset.server;
            await this.loadServerData();
        }
    }

    async switchServer(serverId) {
        document.querySelectorAll('.server-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        document.querySelector(`[data-server="${serverId}"]`).classList.add('active');

        this.currentServer = serverId;
        await this.loadServerData();
    }

    async switchTab(tabName) {
        if (tabName === 'members' && this.currentMembers.length === 0) {
            await this.loadMembers();
        } else if (tabName === 'roles') {
            await this.loadRoles();
        } else if (tabName === 'audit') {
            await this.loadAuditLogs();
        } else if (tabName === 'messages') {
            await this.loadChannels();
        } else if (tabName === 'overview') {
            await this.loadServerStats();
        }
    }

    async loadServerData() {
        if (!this.currentServer) return;

        try {
            await this.loadServerStats();
            
            const activeTab = document.querySelector('.management-tab.active');
            if (activeTab) {
                await this.switchTab(activeTab.dataset.tab);
            }
        } catch (error) {
            console.error('Error loading server data:', error);
            this.showNotification('Error loading server data', 'error');
        }
    }

    async loadServerStats() {
        if (!this.currentServer) return;

        try {
            const response = await axios.get(`/discord-management/server/${this.currentServer}/stats`);
            
            if (response.data.success) {
                const stats = response.data.stats;
                
                const memberCount = document.getElementById('memberCount');
                const onlineCount = document.getElementById('onlineCount');
                const channelCount = document.getElementById('channelCount');
                const roleCount = document.getElementById('roleCount');
                
                if (memberCount) memberCount.textContent = stats.memberCount.toLocaleString();
                if (onlineCount) onlineCount.textContent = stats.onlineCount.toLocaleString();
                if (channelCount) channelCount.textContent = stats.channelCount.toLocaleString();
                if (roleCount) roleCount.textContent = stats.roleCount.toLocaleString();
                
            } else {
                console.error('Failed to load server stats:', response.data.error);
            }
        } catch (error) {
            console.error('Error loading server stats:', error);
            ['memberCount', 'onlineCount', 'channelCount', 'roleCount'].forEach(id => {
                const element = document.getElementById(id);
                if (element) element.textContent = '0';
            });
        }
    }

    async loadMembers() {
        if (!this.currentServer) return;

        const membersList = document.getElementById('membersList');
        if (!membersList) return;

        try {
            membersList.innerHTML = '<div style="text-align: center; padding: 2rem; color: var(--text-secondary);"><i class="fas fa-spinner fa-spin"></i> Loading members...</div>';

            const response = await axios.get(`/discord-management/server/${this.currentServer}/members?page=1&limit=50`);
            
            if (response.data.success) {
                this.currentMembers = response.data.members;
                this.renderMembers(this.currentMembers);
            } else {
                membersList.innerHTML = '<div style="text-align: center; padding: 2rem; color: var(--danger-color);">Error loading members</div>';
            }
        } catch (error) {
            console.error('Error loading members:', error);
            membersList.innerHTML = '<div style="text-align: center; padding: 2rem; color: var(--danger-color);">Error loading members</div>';
        }
    }

    renderMembers(members) {
        const membersList = document.getElementById('membersList');
        if (!membersList) return;

        if (members.length === 0) {
            membersList.innerHTML = '<div style="text-align: center; padding: 2rem; color: var(--text-secondary);">No members found</div>';
            return;
        }

        const html = members.map(member => {
            const user = member.user;
            const avatar = user.avatar 
                ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=64`
                : 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMjAiIGN5PSIyMCIgcj0iMjAiIGZpbGw9IiM1ODY1RjIiLz4KPHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTEyIDJDNi40OCAyIDIgNi40OCAyIDEyUzYuNDggMjIgMTIgMjJTMjIgMTcuNTIgMjIgMTJTMTcuNTIgMiAxMiAyWk0xMiA2QzEzLjY2IDYgMTUgNy4zNCAxNSA5UzEzLjY2IDEyIDEyIDEyUzEwLjM0IDEwLjY2IDkgOVMxMC4zNCA2IDEyIDZaTTEyIDIwQzkuMzMgMjAgNi45NiAxOC40MSA2LjEyIDE2SDE3Ljg4QzE3LjA0IDE4LjQxIDE0LjY3IDIwIDEyIDIwWiIgZmlsbD0id2hpdGUiLz4KPC9zdmc+Cjwvc3ZnPg==';

            const roleElements = member.roles?.map(roleId => {
                return `<span class="role-badge">Role</span>`;
            }).join('') || '';

            return `
                <div class="member-item">
                    <img class="member-avatar" src="${avatar}" alt="${user.username}" onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMjAiIGN5PSIyMCIgcj0iMjAiIGZpbGw9IiM1ODY1RjIiLz4KPHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTEyIDJDNi40OCAyIDIgNi40OCAyIDEyUzYuNDggMjIgMTIgMjJTMjIgMTcuNTIgMjIgMTJTMTcuNTIgMiAxMiAyWk0xMiA2QzEzLjY2IDYgMTUgNy4zNCAxNSA5UzEzLjY2IDEyIDEyIDEyUzEwLjM0IDEwLjY2IDkgOVMxMC4zNCA2IDEyIDZaTTEyIDIwQzkuMzMgMjAgNi45NiAxOC40MSA2LjEyIDE2SDE3Ljg4QzE3LjA0IDE4LjQxIDE0LjY3IDIwIDEyIDIwWiIgZmlsbD0id2hpdGUiLz4KPC9zdmc+Cjwvc3ZnPg=='">
                    <div class="member-info">
                        <div class="member-name">${this.escapeHtml(user.global_name || user.username)}</div>
                        <div style="color: var(--text-secondary); font-size: 0.9rem;">@${this.escapeHtml(user.username)} • ${user.id}</div>
                        <div class="member-roles">${roleElements}</div>
                    </div>
                    <div class="member-actions">
                        <button class="btn btn-small btn-warning" onclick="discordManager.quickTimeout('${user.id}')">
                            <i class="fas fa-clock"></i>
                        </button>
                        <button class="btn btn-small btn-danger" onclick="discordManager.quickKick('${user.id}')">
                            <i class="fas fa-user-times"></i>
                        </button>
                        <button class="btn btn-small btn-danger" onclick="discordManager.quickBan('${user.id}')">
                            <i class="fas fa-ban"></i>
                        </button>
                    </div>
                </div>
            `;
        }).join('');

        membersList.innerHTML = html;
    }

    searchMembers(query) {
        if (!query) {
            this.renderMembers(this.currentMembers);
            return;
        }

        const filtered = this.currentMembers.filter(member => {
            const user = member.user;
            return user.username.toLowerCase().includes(query.toLowerCase()) ||
                   user.global_name?.toLowerCase().includes(query.toLowerCase()) ||
                   user.id.includes(query);
        });

        this.renderMembers(filtered);
    }

    async loadChannels() {
        if (!this.currentServer) return;

        try {
            const response = await axios.get(`/discord-management/server/${this.currentServer}/channels`);
            
            if (response.data.success) {
                const channels = response.data.channels;
                
                const channelSelects = document.querySelectorAll('#channelSelect, #embedChannelSelect');
                channelSelects.forEach(select => {
                    let html = '<option value="">Select a channel...</option>';
                    
                    channels.forEach(channel => {
                        const channelType = this.getChannelTypeIcon(channel.type);
                        html += `<option value="${channel.id}">${channelType} ${channel.name}</option>`;
                    });
                    
                    select.innerHTML = html;
                });
                
            } else {
                console.error('Failed to load channels:', response.data.error);
                const channelSelects = document.querySelectorAll('#channelSelect, #embedChannelSelect');
                channelSelects.forEach(select => {
                    select.innerHTML = '<option value="">No channels available</option>';
                });
            }
        } catch (error) {
            console.error('Error loading channels:', error);
            const channelSelects = document.querySelectorAll('#channelSelect, #embedChannelSelect');
            channelSelects.forEach(select => {
                select.innerHTML = '<option value="">Error loading channels</option>';
            });
        }
    }

    getChannelTypeIcon(type) {
        const icons = {
            0: '#',  
            2: '🔊', 
            4: '📁',
            5: '📢',
            10: '🧵',
            11: '🔒',
            12: '📰', 
            13: '📁',
            15: '🎙️' 
        };
        return icons[type] || '#';
    }

    async loadRoles() {
        if (!this.currentServer) return;

        const rolesContainer = document.getElementById('rolesContainer');
        if (!rolesContainer) return;

        try {
            rolesContainer.innerHTML = '<div style="text-align: center; padding: 2rem; color: var(--text-secondary);"><i class="fas fa-spinner fa-spin"></i> Loading roles...</div>';

            const response = await axios.get(`/discord-management/server/${this.currentServer}/roles`);
            
            if (response.data.success) {
                const roles = response.data.roles;
                this.renderRoles(roles);
            } else {
                rolesContainer.innerHTML = '<div style="text-align: center; padding: 2rem; color: var(--danger-color);">Error loading roles</div>';
            }
        } catch (error) {
            console.error('Error loading roles:', error);
            rolesContainer.innerHTML = '<div style="text-align: center; padding: 2rem; color: var(--danger-color);">Error loading roles</div>';
        }
    }

    renderRoles(roles) {
        const rolesContainer = document.getElementById('rolesContainer');
        if (!rolesContainer) return;

        if (roles.length === 0) {
            rolesContainer.innerHTML = '<div style="text-align: center; padding: 2rem; color: var(--text-secondary);">No roles found</div>';
            return;
        }

        const html = roles.map(role => {
            if (role.name === '@everyone') return '';

            const color = role.color ? `#${role.color.toString(16).padStart(6, '0')}` : '#99aab5';
            const permissions = this.parsePermissions(role.permissions);

            return `
                <div class="discord-card" style="margin-bottom: 1rem;">
                    <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                        <div style="width: 20px; height: 20px; border-radius: 50%; background: ${color};"></div>
                        <div>
                            <div style="font-weight: 600; color: ${color};">${this.escapeHtml(role.name)}</div>
                            <div style="color: var(--text-secondary); font-size: 0.9rem;">
                                Position: ${role.position} • Members: ${role.members || 0}
                            </div>
                        </div>
                        <div style="margin-left: auto;">
                            ${role.hoist ? '<span class="role-badge" style="background: var(--accent-color);">Hoisted</span>' : ''}
                            ${role.mentionable ? '<span class="role-badge" style="background: var(--success-color);">Mentionable</span>' : ''}
                            ${role.managed ? '<span class="role-badge" style="background: var(--warning-color); color: black;">Bot</span>' : ''}
                        </div>
                    </div>
                    <div style="display: flex; flex-wrap: wrap; gap: 0.5rem;">
                        ${permissions.map(perm => `<span class="role-badge" style="background: rgba(255,255,255,0.1);">${perm}</span>`).join('')}
                    </div>
                </div>
            `;
        }).filter(html => html).join('');

        rolesContainer.innerHTML = html || '<div style="text-align: center; padding: 2rem; color: var(--text-secondary);">No roles to display</div>';
    }

    parsePermissions(permissions) {
        const permissionFlags = {
            1: 'Create Invite',
            2: 'Kick Members',
            4: 'Ban Members',
            8: 'Administrator',
            16: 'Manage Channels',
            32: 'Manage Guild',
            64: 'Add Reactions',
            128: 'View Audit Log',
            256: 'Priority Speaker',
            512: 'Stream',
            1024: 'View Channel',
            2048: 'Send Messages',
            4096: 'Send TTS Messages',
            8192: 'Manage Messages',
            16384: 'Embed Links',
            32768: 'Attach Files',
            65536: 'Read Message History',
            131072: 'Mention Everyone',
            262144: 'Use External Emojis',
            524288: 'View Guild Insights',
            1048576: 'Connect',
            2097152: 'Speak',
            4194304: 'Mute Members',
            8388608: 'Deafen Members',
            16777216: 'Move Members',
            33554432: 'Use VAD',
            67108864: 'Change Nickname',
            134217728: 'Manage Nicknames',
            268435456: 'Manage Roles',
            536870912: 'Manage Webhooks',
            1073741824: 'Manage Emojis',
            2147483648: 'Use Application Commands',
            4294967296: 'Request to Speak',
            8589934592: 'Manage Events',
            17179869184: 'Manage Threads',
            34359738368: 'Create Public Threads',
            68719476736: 'Create Private Threads',
            137438953472: 'Use External Stickers',
            274877906944: 'Send Messages in Threads',
            549755813888: 'Use Embedded Activities',
            1099511627776: 'Moderate Members'
        };

        const perms = [];
        const permValue = BigInt(permissions);

        for (const [flag, name] of Object.entries(permissionFlags)) {
            if (permValue & BigInt(flag)) {
                perms.push(name);
            }
        }

        const importantPerms = perms.filter(perm => 
            ['Administrator', 'Manage Guild', 'Manage Channels', 'Manage Roles', 
             'Ban Members', 'Kick Members', 'Manage Messages', 'View Audit Log',
             'Manage Nicknames', 'Moderate Members'].includes(perm)
        );

        return importantPerms.length > 0 ? importantPerms : perms.slice(0, 5);
    }

    async loadAuditLogs() {
        if (!this.currentServer) return;

        const auditLogs = document.getElementById('auditLogs');
        if (!auditLogs) return;

        try {
            auditLogs.innerHTML = '<div style="text-align: center; padding: 2rem; color: var(--text-secondary);"><i class="fas fa-spinner fa-spin"></i> Loading audit logs...</div>';

            const response = await axios.get(`/discord-management/server/${this.currentServer}/audit-logs?limit=25`);
            
            if (response.data.success) {
                const logs = response.data.auditLogs;
                this.renderAuditLogs(logs);
            } else {
                auditLogs.innerHTML = '<div style="text-align: center; padding: 2rem; color: var(--danger-color);">Error loading audit logs</div>';
            }
        } catch (error) {
            console.error('Error loading audit logs:', error);
            auditLogs.innerHTML = '<div style="text-align: center; padding: 2rem; color: var(--danger-color);">Error loading audit logs</div>';
        }
    }

    renderAuditLogs(auditData) {
        const auditLogs = document.getElementById('auditLogs');
        if (!auditLogs) return;

        if (!auditData.audit_log_entries || auditData.audit_log_entries.length === 0) {
            auditLogs.innerHTML = '<div style="text-align: center; padding: 2rem; color: var(--text-secondary);">No audit logs found</div>';
            return;
        }

        const logs = auditData.audit_log_entries;
        const users = auditData.users || [];
        const userMap = {};
        users.forEach(user => {
            userMap[user.id] = user;
        });

        const html = logs.map(log => {
            const executor = userMap[log.user_id];
            const actionName = this.getAuditActionName(log.action_type);
            const actionIcon = this.getAuditActionIcon(log.action_type);
            const actionColor = this.getAuditActionColor(log.action_type);

            return `
                <div class="log-item">
                    <div class="log-icon" style="background: ${actionColor};">
                        <i class="${actionIcon}"></i>
                    </div>
                    <div style="flex: 1;">
                        <div style="font-weight: 500;">
                            ${executor ? this.escapeHtml(executor.username) : 'Unknown User'}
                        </div>
                        <div style="color: var(--text-secondary); font-size: 0.9rem;">
                            ${actionName}
                            ${log.target_id ? ` • Target: ${log.target_id}` : ''}
                            ${log.reason ? ` • ${this.escapeHtml(log.reason)}` : ''}
                        </div>
                    </div>
                    <div style="color: var(--text-secondary); font-size: 0.8rem;">
                        ${new Date(log.id / 4194304 + 1420070400000).toLocaleString()}
                    </div>
                </div>
            `;
        }).join('');

        auditLogs.innerHTML = html;
    }

    getAuditActionName(actionType) {
        const actions = {
            1: 'Guild Update',
            10: 'Channel Create',
            11: 'Channel Update',
            12: 'Channel Delete',
            13: 'Channel Overwrite Create',
            14: 'Channel Overwrite Update',
            15: 'Channel Overwrite Delete',
            20: 'Member Kick',
            21: 'Member Prune',
            22: 'Member Ban Add',
            23: 'Member Ban Remove',
            24: 'Member Update',
            25: 'Member Role Update',
            26: 'Member Move',
            27: 'Member Disconnect',
            28: 'Bot Add',
            30: 'Role Create',
            31: 'Role Update',
            32: 'Role Delete',
            40: 'Invite Create',
            41: 'Invite Update',
            42: 'Invite Delete',
            50: 'Webhook Create',
            51: 'Webhook Update',
            52: 'Webhook Delete',
            60: 'Emoji Create',
            61: 'Emoji Update',
            62: 'Emoji Delete',
            72: 'Message Delete',
            73: 'Message Bulk Delete',
            74: 'Message Pin',
            75: 'Message Unpin',
            80: 'Integration Create',
            81: 'Integration Update',
            82: 'Integration Delete',
            83: 'Stage Instance Create',
            84: 'Stage Instance Update',
            85: 'Stage Instance Delete',
            90: 'Sticker Create',
            91: 'Sticker Update',
            92: 'Sticker Delete',
            100: 'Guild Scheduled Event Create',
            101: 'Guild Scheduled Event Update',
            102: 'Guild Scheduled Event Delete',
            110: 'Thread Create',
            111: 'Thread Update',
            112: 'Thread Delete'
        };
        return actions[actionType] || `Unknown Action (${actionType})`;
    }

    getAuditActionIcon(actionType) {
        if ([22, 20].includes(actionType)) return 'fas fa-ban';
        if ([23].includes(actionType)) return 'fas fa-user-check';
        if ([24, 25].includes(actionType)) return 'fas fa-user-edit';
        if ([30, 31, 32].includes(actionType)) return 'fas fa-user-tag';
        if ([10, 11, 12].includes(actionType)) return 'fas fa-hashtag';
        if ([72, 73].includes(actionType)) return 'fas fa-trash';
        if ([1].includes(actionType)) return 'fas fa-cog';
        return 'fas fa-clipboard-list';
    }

    getAuditActionColor(actionType) {
        if ([22, 20, 12, 32, 62, 72, 73].includes(actionType)) return 'var(--danger-color)';
        if ([23].includes(actionType)) return 'var(--success-color)';
        if ([24, 25, 31, 61, 11].includes(actionType)) return 'var(--warning-color)';
        if ([10, 30, 60].includes(actionType)) return 'var(--success-color)';
        return 'var(--primary-color)';
    }

    async banUser(data) {
        try {
            const response = await axios.post(`/discord-management/server/${this.currentServer}/ban`, data);
            if (response.data.success) {
                this.showNotification('User banned successfully', 'success');
                document.getElementById('banForm').reset();
            } else {
                this.showNotification('Failed to ban user: ' + response.data.error, 'error');
            }
        } catch (error) {
            console.error('Error banning user:', error);
            this.showNotification('Error banning user', 'error');
        }
    }

    async kickUser(data) {
        try {
            const response = await axios.post(`/discord-management/server/${this.currentServer}/kick`, data);
            if (response.data.success) {
                this.showNotification('User kicked successfully', 'success');
                document.getElementById('kickForm').reset();
            } else {
                this.showNotification('Failed to kick user: ' + response.data.error, 'error');
            }
        } catch (error) {
            console.error('Error kicking user:', error);
            this.showNotification('Error kicking user', 'error');
        }
    }

    async timeoutUser(data) {
        try {
            const response = await axios.post(`/discord-management/server/${this.currentServer}/timeout`, data);
            if (response.data.success) {
                this.showNotification('User timed out successfully', 'success');
                document.getElementById('timeoutForm').reset();
            } else {
                this.showNotification('Failed to timeout user: ' + response.data.error, 'error');
            }
        } catch (error) {
            console.error('Error timing out user:', error);
            this.showNotification('Error timing out user', 'error');
        }
    }

    async unbanUser(data) {
        try {
            const response = await axios.delete(`/discord-management/server/${this.currentServer}/ban/${data.userId}`, {
                data: { reason: data.reason }
            });
            if (response.data.success) {
                this.showNotification('User unbanned successfully', 'success');
                document.getElementById('unbanForm').reset();
            } else {
                this.showNotification('Failed to unban user: ' + response.data.error, 'error');
            }
        } catch (error) {
            console.error('Error unbanning user:', error);
            this.showNotification('Error unbanning user', 'error');
        }
    }

    async sendMessage(data) {
        try {
            const response = await axios.post(`/discord-management/server/${this.currentServer}/channel/${data.channelId}/message`, {
                content: data.content
            });
            if (response.data.success) {
                this.showNotification('Message sent successfully', 'success');
                document.getElementById('messageForm').reset();
            } else {
                this.showNotification('Failed to send message: ' + response.data.error, 'error');
            }
        } catch (error) {
            console.error('Error sending message:', error);
            this.showNotification('Error sending message', 'error');
        }
    }

    async sendEmbed(data) {
        try {
            const embed = {
                title: data.title,
                description: data.description,
                color: parseInt(data.color.replace('#', ''), 16),
                footer: data.footer ? { text: data.footer } : undefined
            };

            const response = await axios.post(`/discord-management/server/${this.currentServer}/channel/${data.channelId}/message`, {
                embed: embed
            });
            
            if (response.data.success) {
                this.showNotification('Embed sent successfully', 'success');
                document.getElementById('embedForm').reset();
                this.updateEmbedPreview();
            } else {
                this.showNotification('Failed to send embed: ' + response.data.error, 'error');
            }
        } catch (error) {
            console.error('Error sending embed:', error);
            this.showNotification('Error sending embed', 'error');
        }
    }

    async quickTimeout(userId) {
        if (confirm('Timeout this user for 10 minutes?')) {
            await this.timeoutUser({
                userId: userId,
                duration: 10,
                reason: 'Quick timeout'
            });
        }
    }

    async quickKick(userId) {
        if (confirm('Kick this user from the server?')) {
            await this.kickUser({
                userId: userId,
                reason: 'Quick kick'
            });
        }
    }

    async quickBan(userId) {
        if (confirm('Ban this user from the server?')) {
            await this.banUser({
                userId: userId,
                reason: 'Quick ban',
                deleteMessageDays: 0
            });
        }
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'success' ? 'var(--success-color)' : type === 'error' ? 'var(--danger-color)' : 'var(--primary-color)'};
            color: white;
            padding: 1rem 1.5rem;
            border-radius: var(--radius);
            box-shadow: var(--shadow-lg);
            z-index: 9999;
            max-width: 300px;
            opacity: 0;
            transform: translateX(100%);
            transition: all 0.3s ease;
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        requestAnimationFrame(() => {
            notification.style.opacity = '1';
            notification.style.transform = 'translateX(0)';
        });
        
        setTimeout(() => {
            notification.style.opacity = '0';
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 5000);
    }
}

let discordManager;

document.addEventListener('DOMContentLoaded', () => {
    try {
        discordManager = new DiscordManager();
    } catch (error) {
        console.error('Error initializing Discord Manager:', error);
    }
});

window.addEventListener('load', () => {
    if (!discordManager) {
        try {
            discordManager = new DiscordManager();
        } catch (error) {
            console.error('Error initializing Discord Manager (fallback):', error);
        }
    }
});

if (typeof $ !== 'undefined') {
    $(document).ready(() => {
        if (!discordManager) {
            try {
                discordManager = new DiscordManager();
            } catch (error) {
                console.error('Error initializing Discord Manager (jQuery):', error);
            }
        }
    });
}

function showBulkDeleteModal() {
    const channelId = prompt('Enter channel ID:');
    const amount = prompt('How many messages to delete? (max 100)');
    
    if (channelId && amount) {
        axios.post(`/discord-management/server/${discordManager.currentServer}/channel/${channelId}/bulk-delete`, {
            amount: parseInt(amount)
        })
        .then(response => {
            if (response.data.success) {
                discordManager.showNotification('Messages deleted successfully', 'success');
            } else {
                discordManager.showNotification('Failed to delete messages: ' + response.data.error, 'error');
            }
        })
        .catch(error => {
            console.error('Error deleting messages:', error);
            discordManager.showNotification('Error deleting messages', 'error');
        });
    }
}

function showAnnouncementModal() {
    const channelId = prompt('Enter channel ID:');
    const message = prompt('Enter announcement message:');
    
    if (channelId && message) {
        axios.post(`/discord-management/server/${discordManager.currentServer}/channel/${channelId}/message`, {
            content: `📢 **ANNOUNCEMENT** 📢\n\n${message}`
        })
        .then(response => {
            if (response.data.success) {
                discordManager.showNotification('Announcement sent successfully', 'success');
            } else {
                discordManager.showNotification('Failed to send announcement: ' + response.data.error, 'error');
            }
        })
        .catch(error => {
            console.error('Error sending announcement:', error);
            discordManager.showNotification('Error sending announcement', 'error');
        });
    }
}

function showMassRoleModal() {
    discordManager.showNotification('Mass role management feature coming soon!', 'info');
}

function lockdownServer() {
    if (confirm('Are you sure you want to put the server in lockdown mode? This will restrict permissions for most members.')) {
        discordManager.showNotification('Server lockdown feature coming soon!', 'info');
    }
} 